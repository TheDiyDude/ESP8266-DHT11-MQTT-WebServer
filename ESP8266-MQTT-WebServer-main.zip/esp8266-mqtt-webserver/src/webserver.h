
#pragma once

#include "util.h"

void launchWeb(int webtype);
void createWebServer(int webtype);
